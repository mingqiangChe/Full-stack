// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBlog = require('../../../app/model/blog');

declare module 'egg' {
  interface IModel {
    Blog: ReturnType<typeof ExportBlog>;
  }
}
