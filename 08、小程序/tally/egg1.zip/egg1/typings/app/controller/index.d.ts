// This file is created by egg-ts-helper@1.29.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportApi = require('../../../app/controller/api');
import ExportHome = require('../../../app/controller/home');
import ExportRightSun = require('../../../app/controller/rightSun');

declare module 'egg' {
  interface IController {
    api: ExportApi;
    home: ExportHome;
    rightSun: ExportRightSun;
  }
}
