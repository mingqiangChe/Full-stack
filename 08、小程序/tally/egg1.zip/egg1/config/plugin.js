"use strict";

exports.ejs = {
  enable: true,
  package: "egg-view-ejs",
};
// exports.sequelize = {
//   enable: true,
//   package: "egg-sequelize",
// };
exports.mysql = {
  enable: true,
  package: "egg-mysql",
};
exports.cors = {
  enable: true,
  package: "egg-cors",
};
exports.jwt = {
  enable: true,
  package: "egg-jwt",
};
// exports.alinode = {
//   enable: true,
//   package: "egg-alinode",
// };
